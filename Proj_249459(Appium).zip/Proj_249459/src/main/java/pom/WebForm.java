package pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import base.AndriodActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class WebForm  extends AndriodActions{

	public WebForm(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver),this);
		
	}
	
	//Locators
	
	//Signup
	
	@AndroidFindBy(xpath="//android.widget.Button[@content-desc=\"Webview\"]/android.widget.TextView[2]")
	WebElement web;
	
	@AndroidFindBy(xpath="//android.widget.Button[@content-desc=\"Login\"]/android.widget.TextView[2]")
	WebElement login;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"button-sign-up-container\"]/android.view.ViewGroup/android.widget.TextView")
	WebElement signup;
	
	@AndroidFindBy(accessibility="input-email")
	WebElement email;
	
	@AndroidFindBy(xpath="//android.widget.EditText[@content-desc=\"input-password\"]")
	WebElement pass;
	
	@AndroidFindBy(xpath="//android.widget.EditText[@content-desc=\"input-repeat-password\"]")
	WebElement conpass;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"button-SIGN UP\"]")
	WebElement submit;
	
	@AndroidFindBy(id="android:id/button1")
	WebElement ok;
	
	//Login
	
	@AndroidFindBy(accessibility="input-email")
	WebElement emaillog;
	
	@AndroidFindBy(xpath="//android.widget.EditText[@content-desc=\"input-password\"]")
	WebElement passlog;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"button-LOGIN\"]")
	WebElement log;
	
	@AndroidFindBy(id="android:id/button1")
	WebElement logok;
	
	@AndroidFindBy(xpath="//android.widget.Button[@content-desc=\"Swipe\"]/android.widget.TextView[2]")
	WebElement swipe;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"Carousel\"]/android.view.ViewGroup/android.view.ViewGroup[2]")
	WebElement img2;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"Carousel\"]/android.view.ViewGroup/android.view.ViewGroup[3]")
	WebElement img3;
	

	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"Carousel\"]/android.view.ViewGroup/android.view.ViewGroup[4]")
	WebElement img4;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"Carousel\"]/android.view.ViewGroup/android.view.ViewGroup[5]")
	WebElement img5;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"Carousel\"]/android.view.ViewGroup/android.view.ViewGroup[6]/android.view.ViewGroup")
	WebElement img6;
	
	
	
	
	//Functions for different operations
	
	//Signup
	
	public void webclick() {
		web.click();
	}
	
	public void loginclick() {
		login.click();
	}
	
	public void signupclick() {
		signup.click();
	}
	
	public void emailtxt(String email1) {
		email.sendKeys(email1);
	}
	
	public void passtxt(String pass1) {
		pass.sendKeys(pass1);
	}
	
	public void conpasstxt(String conpass1) {
		conpass.sendKeys(conpass1);
	}
	public void submitclick() {
		submit.click();
	}
	
	public void okclick() {
		ok.click();
	}
	
	//Login
	
	public void emailtxtlog(String emaillog1) {
		emaillog.sendKeys(emaillog1);
	}

	public void passtxtlog(String passlog1) {
		passlog.sendKeys(passlog1);
	}

	public void logclick() {
		log.click();
	}
   
	public void logokclick() {
		logok.click();
	}
	
	//Swipe
	
	public void swipeclick() {
		swipe.click();
	}
	
	public void swipeimage2() {

		img2.click();
    }
	
	public void swipeimage3() {
 
		img3.click();
		
	}
	public void swipeimage4() {
		 
		img4.click();
    }
	
	public void swipeimage5() {
		 
		img5.click();
    }
	
	public void swipeimage6() {
		 
		img6.click();
    }
}
