package pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import base.AndriodActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class WebForm_DragndDrop extends AndriodActions{

	
	public WebForm_DragndDrop(AndroidDriver driver) {
		super(driver);

		this.driver=driver;

		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	

	//Locators
	//Drag and Drop

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Drag\"]/android.widget.TextView[2]")

	private WebElement drag;

	

	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"drag-c1\"]/android.widget.ImageView")

	private WebElement slot1;

	

	

	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"drag-c3\"]/android.widget.ImageView")

	private WebElement slot2;

	

	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"drag-r1\"]/android.widget.ImageView")

	private WebElement slot3;

	

	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"drag-r3\"]/android.widget.ImageView")

	private WebElement slot4;

	

	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"drag-l2\"]/android.widget.ImageView")

	private WebElement slot5;

	

	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"drag-l3\"]/android.widget.ImageView")

	private WebElement slot6;

	

	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"drag-l1\"]/android.widget.ImageView")

	private WebElement slot7;

	

	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"drag-c2\"]/android.widget.ImageView")

	private WebElement slot8;

	

	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"drag-r2\"]/android.widget.ImageView")

	private WebElement slot9;

	

	@AndroidFindBy(uiAutomator = "UiSelector().text(\"Retry\")")

	private WebElement retry;

	

	@AndroidFindBy(uiAutomator = "UiSelector().text(\"Drag and Drop\")")

	private WebElement draganddrop;

	

	public void dragclick() {

		drag.click();

	}

	

	public void dragslot1() {

		dragAndDrop(slot1, 554, 678);

	}

	

	public void dragslot2() {

		dragAndDrop(slot2, 538, 1105);

	}

	

	public void dragslot3() {

		dragAndDrop(slot3, 743, 642);

	}

	

	public void dragslot4() {

		dragAndDrop(slot4, 760, 1129);

	}

	

	public void dragslot5() {

		dragAndDrop(slot5, 353, 857);

	}

	

	public void dragslot6() {

		dragAndDrop(slot6, 333, 1150);

	}

	

	public void dragslot7() {

		dragAndDrop(slot7, 333, 661);

	}

	

	public void dragslot8() {

		dragAndDrop(slot8, 522, 916);

	}

	

	public void dragslot9() {

		dragAndDrop(slot9, 750, 883);

	}

	

	public boolean draganddropPresent() {

		return draganddrop.isDisplayed();

	}

	

	public boolean retryPresent() {

		return retry.isDisplayed();

	}

 

	

}
