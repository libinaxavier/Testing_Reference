package base;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.google.common.collect.ImmutableMap;

import io.appium.java_client.android.AndroidDriver;
import utilities.Dateutils;

public class AndriodActions {
	public static  AndroidDriver driver;

	public static ExtentReports extent;
	public static ExtentTest logger;
	public static String timestamp = Dateutils.getTimeStamp();
	
	public AndriodActions(AndroidDriver driver)
	{
	
		this.driver = driver;
	}

	//Screenshots
	public static void takeScreenShot(String filePath) {
		try {
			File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(src, new File(filePath));
		}catch(Exception e) {
			e.printStackTrace();
		}

		
	}
	
	//Drag and Drop
	
     public static void dragAndDrop(WebElement elemnt,int axis1, int axis2) {

		

		((JavascriptExecutor) driver).executeScript("mobile:dragGesture", ImmutableMap.of(

				"elementId",((RemoteWebElement)elemnt).getId(),

				"endX",axis1,

				"endY",axis2

				

				));

	}

}
