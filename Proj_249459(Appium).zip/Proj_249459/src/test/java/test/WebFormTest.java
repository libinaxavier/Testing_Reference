package test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.BaseTest;
import io.appium.java_client.AppiumBy;
import pom.WebForm;
import pom.WebForm_DragndDrop;

@Listeners(utilities.SampleListener.class)
public class WebFormTest  extends BaseTest{
	
	//Read Json file
	
	//Signup
	
	@DataProvider(name = "logData1")
	public Object[][] getData() throws IOException
	{
	List<HashMap<String, String>>	data =getJsonData(System.getProperty("user.dir")+"\\src\\TestData\\signin.json");
	Object[][] testData = new Object[data.size()][3];
	for (int i = 0; i < data.size(); i++) {
	HashMap<String, String> row = data.get(i);
	testData[i][0] = row.get("email");
	testData[i][1] = row.get("pssword");
	testData[i][2] = row.get("conpass");
	}
	return testData;
	}
	
	//Login
	
	@DataProvider(name = "logData2")
	public Object[][] getData1() throws IOException
	{
	List<HashMap<String, String>>	data =getJsonData(System.getProperty("user.dir")+"\\src\\TestData\\login.json");
	Object[][] testData = new Object[data.size()][2];
	for (int i = 0; i < data.size(); i++) {
	HashMap<String, String> row = data.get(i);
	testData[i][0] = row.get("logemail");
	testData[i][1] = row.get("logpssword");
	}
	return testData;
	}
	
	//Different testcases
	
	//Open
	
	@Test(priority=0)
	public void  opentest() {
		WebForm wf=new WebForm(driver);
		
		SoftAssert softassert=new SoftAssert();
		String webtext="Webview";
		softassert.assertEquals(driver.findElement(AppiumBy.xpath("//android.widget.Button[@content-desc=\"Webview\"]/android.widget.TextView[2]")).getText()
		.equalsIgnoreCase(webtext), true);
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Webview\"]/android.widget.TextView[2]")).isDisplayed());
						
			});
		
		
		wf.webclick();
	}

	//Signup
	
	@Test(priority=1,dataProvider="logData1")
	public void signintest(String email,String password,String conpass) {
		WebForm wf=new WebForm(driver);
		wf.loginclick();
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"button-sign-up-container\"]/android.view.ViewGroup/android.widget.TextView")).isDisplayed());
						
			});
		
		wf.signupclick();
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.xpath("//android.widget.EditText[@content-desc=\"input-email\"]")).isDisplayed());
						
			});
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.xpath("//android.widget.EditText[@content-desc=\"input-password\"]")).isDisplayed());
						
			});
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.xpath("//android.widget.EditText[@content-desc=\"input-repeat-password\"]")).isDisplayed());
						
			});
		
		wf.emailtxt(email);
		wf.passtxt(password);
		wf.conpasstxt(conpass);
		wf.submitclick();
	    wf.okclick();
	}
	
	//Login
	
	@Test(priority=2,dataProvider="logData2")
	public void logintest(String logemail1,String logpassword1) {
		WebForm wf=new WebForm(driver);
		
		SoftAssert softassert=new SoftAssert();
		String logtext="Login";
		softassert.assertEquals(driver.findElement(AppiumBy.xpath("//android.widget.Button[@content-desc=\"Login\"]/android.widget.TextView[2]")).getText()
		.equalsIgnoreCase(logtext), true);
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Login\"]/android.widget.TextView[2]")).isDisplayed());
						
			});
		
		wf.loginclick();
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.xpath("//android.widget.EditText[@content-desc=\"input-email\"]")).isDisplayed());
						
			});
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.xpath("//android.widget.EditText[@content-desc=\"input-password\"]")).isDisplayed());
						
			});
		
		wf.emailtxtlog(logemail1);
		wf.passtxtlog(logpassword1);
		wf.logclick();
		wf.logokclick();
	}

	//Swipe
	
	@Test(priority=3)
		public void swipetest() {
			WebForm wf=new WebForm(driver);
			
			SoftAssert softassert=new SoftAssert();
			String swipetext="Swipe";
			softassert.assertEquals(driver.findElement(AppiumBy.xpath("//android.widget.Button[@content-desc=\"Swipe\"]/android.widget.TextView[2]")).getText()
			.equalsIgnoreCase(swipetext), true);
			
			SoftAssertions.assertSoftly(softAssertions -> {
			       softAssertions.assertThat(driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Swipe\"]/android.widget.TextView[2]")).isDisplayed());
							
				});
			
			wf.swipeclick();
			wf.swipeimage2();
			wf.swipeimage3();
			wf.swipeimage4();
			wf.swipeimage5();
			wf.swipeimage6();
		}
	
	//Drag and Drop
	
	@Test(priority=4)
	public void dragTest() throws InterruptedException {

		WebForm_DragndDrop drag=new WebForm_DragndDrop(driver);

		drag.dragclick();
		
		SoftAssertions.assertSoftly(softAssertions -> {

			 softAssertions.assertThat(drag.draganddropPresent()).isTrue();

			 });

		drag.dragslot1();

		drag.dragslot2();

		drag.dragslot3();

		drag.dragslot4();

		drag.dragslot5();

		drag.dragslot6();

		drag.dragslot7();

		drag.dragslot8();

		drag.dragslot9();

		SoftAssertions.assertSoftly(softAssertions -> {

			 softAssertions.assertThat(drag.retryPresent()).isTrue();

			 });

		

	}

}
