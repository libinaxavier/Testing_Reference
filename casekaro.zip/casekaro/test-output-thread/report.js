$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"67e8c49c-e0a6-41c6-9bc2-396159966075","feature":"Login page feature","scenario":"Login page title","start":1692890559663,"group":1,"content":"","tags":"","end":1692890571391,"className":"passed"},{"id":"10eab54e-eaf9-4288-896b-4b184a4d996c","feature":"Login page feature","scenario":"Login with correct credentials","start":1692890571409,"group":1,"content":"","tags":"","end":1692890590355,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});