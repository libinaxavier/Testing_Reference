package Utility;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import Base.BaseUI;

public class ExtendReportManager extends BaseUI{

	public static ExtentReports extent;
	public static ExtentSparkReporter spark;
	public static ExtentReports getReportInstance() {
		 extent= new ExtentReports();
		 String repName= "TestReport-" +BaseUI.timestamp+".html";
		 spark= new ExtentSparkReporter(System.getProperty("user.dir") + "/TestOutput/"+repName);
		 extent.attachReporter(spark);
		 extent.setSystemInfo("Host Name", "UST");
		 extent.setSystemInfo("Environment", "Production");
		 extent.setSystemInfo("User Name", "Aiswarya");
		 spark.config().setDocumentTitle("Title of the Report comes here");
		 spark.config().setReportName("Name of the Report comes here");
		 spark.config().setTheme(Theme.DARK);
		 return extent;
			}
	
}
