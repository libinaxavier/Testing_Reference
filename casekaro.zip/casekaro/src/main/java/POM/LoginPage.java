package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

//for login with credentials
public class LoginPage {
	private WebDriver driver;
	public LoginPage(WebDriver driver) {
	this.driver=driver;
	}
	
	//Locators
	By login=By.xpath("//a[@class='site-header__icon site-header__account']");
	By emailid=By.id("CustomerEmail");
	By pwd=By.id("CustomerPassword");
	By signInButton = By.xpath("//input[@value='Sign In']");
	
	
	public String getLoginPageTitle() {
		return driver.getTitle();  //get the title of the website
	}

	public void loginPage() {
		driver.findElement(login).click(); //click login button
	}
	
	
	public void sendemail(String email) {
		driver.findElement(emailid).sendKeys(email); //passing email
	}
	
	public void sendPassword(String password) {
		driver.findElement(pwd).sendKeys(password); //passing password
	}
	
	public void clickSubmit() {
		driver.findElement(signInButton).click(); //click on submit button
		
	}

}
