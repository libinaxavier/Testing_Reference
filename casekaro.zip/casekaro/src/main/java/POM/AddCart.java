package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.BaseUI;

//for Add to cart function
public class AddCart extends BaseUI{
	WebDriver driver;
	createLogin createlogin;
	public AddCart(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	//finding the element by giving the locators
	@FindBy(xpath ="//span[text()='Pop Holders']")
	WebElement PopDrop;
	
	@FindBy(id ="SortBy")
	WebElement popFeatured;
	
	@FindBy(xpath ="//option[text()='Alphabetically, A-Z']")
	WebElement featureselect;
	
	@FindBy(xpath ="//a[@class='grid-view-item__link grid-view-item__image-container full-width-link']")
	WebElement productClick;
	
	@FindBy(id ="AddToCart-product-template")
	WebElement productcart;

	@FindBy(xpath ="//a[@class='btn btn--secondary cart__continue small--hide cart__submit-control']")
	WebElement continueShop;
	
	@FindBy(xpath ="//a[@class='site-header__logo-link']")
	WebElement caseHome;
	
	//functions to click different options
	
	public void  popDrop() { 
		clickOn(PopDrop);	//select option from the Dropdown 
	}
	
	public void  popfeature() {
		clickOn(popFeatured);	//click the pop features
	}
	
	public void  FeatureSelect() {
		clickOn(featureselect);	  //select the feature
	}
	
	public void  ProductClick() {
		clickOn(productClick);	  //click the product
	}
	
	public void  productCart() {
		clickOn(productcart);	//add the product into cart
	}
	
	public void  ContinueShop() {
		clickOn(continueShop);	  //click continue shopping button
	}
	
	public void  CaseHome() {
		clickOn(caseHome);	//click home button
	}
}
