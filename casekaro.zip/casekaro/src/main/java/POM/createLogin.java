package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import Base.BaseUI;


//For create new user
public class createLogin extends BaseUI{
	WebDriver driver;
	createLogin createlogin;
	public createLogin(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	//identifying element by locators
	@FindBy(xpath ="//a[@class='site-header__icon site-header__account']")
	WebElement Login;
	
	@FindBy(id ="customer_register_link")
	WebElement CreateAcc;
	
	@FindBy(id ="FirstName")
	WebElement firstname;
	
	@FindBy(id ="LastName")
	WebElement lastname;
	
	@FindBy(id ="Email")
	WebElement email;
	
	@FindBy(id ="CreatePassword")
	WebElement password;
	
	@FindBy(xpath ="//input[@value='Create']")
	WebElement createButton;
	
	@FindBy(xpath ="//div[@class='recaptcha-checkbox-border']")
	WebElement checkBox;
	
	@FindBy(xpath ="//a[@class='site-header__icon site-header__account']")
	WebElement checkBoxSubmit;
	
	@FindBy(xpath ="//a[@class='site-header__icon site-header__account']")
	WebElement LoginNext;
	
	@FindBy(id ="CustomerEmail")
	WebElement loginemail;
	
	@FindBy(id ="CustomerPassword")
	WebElement loginpassword;
	
	@FindBy(xpath ="//input[@value='Sign In']")
	WebElement loginsubmit;

	public void  loginacc() {
		clickOn(Login);	 //click Login button
	}
	
	public void  createacc() {
		clickOn(CreateAcc);	 //click create-account button
	}
	
	public void  FirstName(String first) {
		sendtext(firstname, first);	// enter first name
	}
	
	public void  LastName(String last) {
		sendtext(lastname, last);	//enter lastname
	}
	
	public void  Email(String email1) {
		sendtext(email, email1);	//enter email
	}
	
	public void  Password(String pass) {
		sendtext(password, pass);	//enter password
	}
	
	public void  createbutton() {
		clickOn(createButton);	//click on create-account button
	}

	public void  checkbox() {
		clickOn(checkBox);	//check(tick) the checkbox
	}

	public void  checkSubmit() {
		clickOn(checkBoxSubmit);	//click the submit button
	}
	
	public void  loginnext() {
		clickOn(LoginNext);	// click login button
	}
	
	public void  loginemail(String email) {
		sendtext(loginemail, email);	//enter mail id
	}
	
	public void  loginpassword(String pass) {
		sendtext(loginpassword, pass);	//enter password
	}
	
	public void  loginSubmit() {
		clickOn(loginsubmit);	//click submit button
	}
}
