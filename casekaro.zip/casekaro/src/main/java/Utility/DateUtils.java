package Utility;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {
	public static String getTimeStamp() {
		// TODO Auto-generated method stub
		//generating date
		return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	}
}
