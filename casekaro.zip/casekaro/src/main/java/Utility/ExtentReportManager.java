package Utility;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import Base.BaseUI;

public class ExtentReportManager  extends BaseUI{
	public static ExtentReports extent;
	public static ExtentSparkReporter spark;
	//************Getting report instance for Extent report
	public static ExtentReports getReportInstance() {
	extent=new ExtentReports();
	String repName="TestReport-"+BaseUI.timestamp+".html";
	//path where the extend report going to save
	spark=new ExtentSparkReporter(System.getProperty("user.dir")+"//TestOutput//"+repName);
	extent.attachReporter(spark);
	//system information
	extent.setSystemInfo("Host Name","UST");
	extent.setSystemInfo("Environment", "Production");
	//user information
	extent.setSystemInfo("User Name", "Libina");
	spark.config().setDocumentTitle("Title of the report");
	//name of the report
	spark.config().setReportName("name of the report");
	//dark theme
	spark.config().setTheme(Theme.DARK);
	return extent;
	}
}
