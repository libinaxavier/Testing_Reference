package Utility;

import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import Base.BaseUI;


public class SampleListener extends TestListenerAdapter{
	public static ExtentReports extent;
	public static ExtentTest logger;
	public void onStart(ITestContext context) {
	extent=ExtentReportManager.getReportInstance();
	}
	//start a test
	public void onTestStart(ITestResult result) {
	logger=extent.createTest(result.getName());
	BaseUI.logger=logger;
	}
	//saving the screenshots and reports of successful test
	public void onTestSuccess(ITestResult result) {
	logger.log(Status.PASS,
	MarkupHelper.createLabel(result.getName(), ExtentColor.GREEN));
	logger.log(Status.PASS, "Testcase passed");
	String folderName=result.getInstanceName();
	String testName=result.getName();
	String filePath=System.getProperty("user.dir")+
			"//TestOutput//Screenshots//"
              +folderName+"/"+testName+"/"
              +testName+"_Passed.png";
	
	try
	{
		BaseUI.takeScreenShot(filePath);
	}
	catch(Exception  e)
	{
		e.printStackTrace();
	}
	}
	//saving the screenshots and reports of failed test
	public void onTestFailure(ITestResult r) {
		logger.log(Status.FAIL,
				MarkupHelper.createLabel(r.getName(), ExtentColor.RED));
				logger.log(Status.FAIL, "Testcase failed");
				String folderName=r.getInstanceName();
				String testName=r.getName();
				String filePath=System.getProperty("user.dir")+
						"//TestOutput//Screenshots//"
			              +folderName+"/"+testName+"/"
			              +testName+"_Failed.png";
				
				try
				{
					BaseUI.takeScreenShot(filePath);
				}
				catch(Exception  e)
				{
					e.printStackTrace();
				}
	}

	//saving the screenshots and reports of skipped test
	public void onTestSkipped(ITestResult tr) {
		logger=extent.createTest(tr.getName());
		logger.log(Status.SKIP,MarkupHelper.createLabel(tr.getName(), ExtentColor.ORANGE) );
	}
	
	//end test
	public void onFinish(ITestContext text) {
		extent.flush();
		
	}
}
