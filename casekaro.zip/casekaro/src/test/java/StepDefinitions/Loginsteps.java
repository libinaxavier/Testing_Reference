package StepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import Base.BrowserConfig;
import POM.LoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class Loginsteps {
	
	private static String title;
	public WebDriver driver=BrowserConfig.getBrowser();
	public LoginPage login=new LoginPage(driver);
	

@Given("user is on login page")
public void user_is_on_login_page() {
    // check whether the user is on login page or not
	driver.get("https://casekaro.com/");
}

@When("user gets the title of page")
public void user_gets_the_title_of_page() {
    //get the title of the login page

	title=login.getLoginPageTitle();
	System.out.println(title);
}

@Then("page title be {string}")
public void page_title_be(String titlename) {
	//checking the title name
	title=login.getLoginPageTitle();
	Assert.assertEquals("Buy Mobile Back Covers and Cases at just Rs.99 – Casekaro",titlename);
}


@When("user click the signin button")
public void user_click_the_signin_button() {  //signin button click
  login.loginPage();
}


@When("user enters username {string}") 
public void user_enters_username(String email) {  //entering username
   login.sendemail(email);
}

@When("user enters password {string}")
public void user_enters_password(String password) {  //enetring password
   login.sendPassword(password);
}

@When("user clicks on Login button")
public void user_clicks_on_login_button() { //click on login button
	login.clickSubmit();
}


@Then("page title should be {string}")
public void page_title_should_be(String string) {  //check whether the page title is string or not
	title=login.getLoginPageTitle();
	Assert.assertEquals(title, string);
}

}
