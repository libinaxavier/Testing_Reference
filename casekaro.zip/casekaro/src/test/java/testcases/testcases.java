package testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Base.BaseUI;
import POM.AddCart;
import POM.createLogin;
import Utility.ExcelUtilities;
import Utility.excelUtility;

@Listeners(Utility.SampleListener.class)
public class testcases extends BaseUI {

	WebDriver driver;
	createLogin login;
	AddCart cart;
	String[][] data;
	
	//the function setup() will run before the test methods
	@BeforeTest
	public void setup() {
		driver = invokeBrowser();
		openBrowser("appURL");
	}
	//Data driven
	@DataProvider(name = "testdata")
	public Object[][] testdata(){
		data= excelUtility.testdata();
		return data;
	}
	
	@DataProvider(name = "testData")
	public Object[][] testData(){
		data= ExcelUtilities.testData();
		return data;
	}
	@Test(priority=0)
	public void accoutCase() {
		createLogin login=new createLogin(driver);
		String a=driver.getCurrentUrl(); 
		//test whether the url is correct or not
		 SoftAssertions.assertSoftly(softAssertions -> {
		 softAssertions.assertThat(a.contains("https://casekaro.com/"));
		 });
		 //test whether the login button is displayed or not
		 SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//a[@class='site-header__logo-link']")).isDisplayed());});
		//test the test FREE Shipping above ₹299 is displayed or not
		 SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//p[text()='FREE Shipping above ₹299']")).isDisplayed());});
		
		login.loginacc();
		
	}
	
	@Test(priority=1,dataProvider = "testdata")
	public void accreg(String first,String last,String email,String pass) {
		createLogin login=new createLogin(driver);
		
		login.createacc(); // create-account button click
		//test whether the cerate account button is displayed or not
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//h1[text()='Create Account']")).isDisplayed());});
		login.FirstName(first); //entering first name
		login.LastName(last);   //entering last name
		login.Email(email);     //entering email
		login.Password(pass);   //entering password
		
		login.createbutton();   //click on create_account button
		login.checkbox();      //checkbox selection
		login.checkSubmit();   //click submit button
		
	}
	
	@Test(priority=2,dataProvider = "testData")
	public void accLogin(String email,String pass) {
		createLogin login=new createLogin(driver);
		login.loginnext(); //click on login
		
	//check whether the login button is displayed or not
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//h1[text()='Login']")).isDisplayed());});
		
		login.loginemail(email); //passing email
		login.loginpassword(pass); //passing password
		login.loginSubmit();       //click on submit button
		login.checkbox();          //select checkbox
		login.checkSubmit();       //click on submit button
	
	}
	

	@Test(priority=3)
	public void CartAdd() {
		AddCart cart=new AddCart(driver);
		cart.popDrop();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//span[@role='text']")).isDisplayed());});
		
		cart.popfeature();
		cart.FeatureSelect();
		cart.ProductClick();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//h1[text()='Abstract Printed Pop Holder']")).isDisplayed());});
		
		cart.productCart();
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//h1[text()='Your cart']")).isDisplayed());});
		
		cart.ContinueShop();
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//span[@role='text']")).isDisplayed());});
		
		cart.CaseHome();
		
		
	}
	
}