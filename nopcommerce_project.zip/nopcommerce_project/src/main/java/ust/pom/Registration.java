package ust.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.base.DriverUtils;

public class Registration  extends DriverUtils{
	
	private WebDriver driver;

	public Registration(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(linkText="Register")
	private WebElement regbut;
	
	@FindBy(id="FirstName")
	private WebElement fname;
	
	@FindBy(id="LastName")
	private WebElement lname;
	
	@FindBy(id="Email")
	private WebElement email;
	
	@FindBy(id="Password")
	private WebElement pass;
	
	@FindBy(id="ConfirmPassword")
	private WebElement conpass;
	
	@FindBy(id="register-button")
	private WebElement regbutt;
	
	@FindBy(id="FirstName-error")
	private WebElement fnameempty;
	
	@FindBy(id="LastName-error")
	private WebElement lnameempty;
	
	@FindBy(id="Email-error")
	private WebElement emailempty;
	
	@FindBy(id="Password-errorr")
	private WebElement passempty;
	
	@FindBy(id="ConfirmPassword-error")
	private WebElement conpassempty;
	
	public void RegBut() {
		clickOn(regbut);
	}
	
	public void Fname(String fname1) {
	sendtext(fname,fname1);
    }
	
	public void Lname(String lname1) {
		sendtext(lname,lname1);
	    }
	
	public void Email(String email1) {
		sendtext(email,email1);
	    }
	
	public void Pass(String pass1) {
		sendtext(pass,pass1);
	    }
	
	public void ConPass(String conpass1) {
		sendtext(conpass,conpass1);
	    }
	
	public void RegButt() {
		clickOn(regbutt);
	    }
	
	public String getURL(){
		String url=driver.getCurrentUrl();
		return url;
    }
	
	public String fnameEmpty() {
		return  rettext(fnameempty);
    }
	
	public String LnameEmpty() {
		return  rettext(lnameempty);
	}
	public String EmailEmpty() {
		return  rettext(emailempty);
	}
	public String PassEmpty() {
		return  rettext(passempty);
	}
	public String ConPassEmpty() {
		return  rettext(conpassempty);
	}
}
