package ust.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.base.DriverUtils;

public class Purchasing1 extends DriverUtils{
	private WebDriver driver;

	public Purchasing1(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="small-searchterms")
	private WebElement search;
	
	@FindBy(xpath="(//button[text()='Search'])[1]")
	private WebElement searchbut;
	
	@FindBy(xpath="(//button[text()='Search'])[2]")
	private WebElement searchbut1;
	
	@FindBy(linkText="Apple MacBook Pro 13-inch")
	private WebElement item;
	
	@FindBy(id="add-to-cart-button-4")
	private WebElement addtocart;
	
	@FindBy(linkText="shopping cart")
	private WebElement shopcart;
	
	@FindBy(id="termsofservice")
	private WebElement termsndservice;
	
	@FindBy(id="checkout")
	private WebElement checkout;
	
	public void Search(String search1) {
		sendtext(search,search1);
		
	}
	public void SearchBut() {
		clickOn(searchbut);
		
	}
	
	public void SearchBut1() {
		clickOn(searchbut1);
		ScrollDownToElement();
	}
	
	public void Item() {
		clickOn(item);
		ScrollDownToElement();
	}
	
	public void AddToCart() {
		clickOn(addtocart);
		
	}
	
	public void ShoppingCart() {
		clickOn(shopcart);
		ScrollDownToElement();
		
	}
	
	public void termsAndService() {
		clickOn(termsndservice);
		
	}
	
	public void checkOut() {
		clickOn(checkout);
		
	}
	
	
	
//	public String disError() {
//		return  rettext(disempty);
//		
//	}
//	
	
	
	public String getURL() {
		String url=driver.getCurrentUrl();
		return url;
	}
    
}
