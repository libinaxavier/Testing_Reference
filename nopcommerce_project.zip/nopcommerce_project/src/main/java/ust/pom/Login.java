package ust.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.base.DriverUtils;

public class Login extends DriverUtils{
	private WebDriver driver;

	public Login(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")
	private WebElement logbut;
	  @FindBy(id="Email")
	  WebElement Email;
	  
	  @FindBy(id="Password")
	  WebElement Password;
	  
	  @FindBy(xpath="//button[@class='button-1 login-button']")
	  WebElement submit;
	  
	  public String getTitle() {
		  return driver.getTitle();
		  }
		  public void login() {
			  clickOn(logbut);
			  }
		  public void Email(String email) {
			  sendtext(Email,email);
			  }
		  public void password(String uname) {
			  sendtext(Password,uname);
			  }
		  
		  public void submit() {
			  clickOn(submit);
			  }
		  
}
