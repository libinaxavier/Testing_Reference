package ust.base;

import java.io.File;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import ust.utils.DateUtils;
import ust.utils.FileIO;




public class DriverUtils {
	private static WebDriver driver;
	public static Properties prop;
	public static String browserChoice;
	public static String r1;
	
	public static ExtentReports extent;
	public static ExtentTest logger;
	public static String timestamp = DateUtils.getTimeStamp();
	
	

	public DriverUtils() {
		prop=FileIO.initProperties();
	}
	/*****************invoke browser**************/
	public static WebDriver invokebrowser() {
		browserChoice=prop.getProperty("browserName");
		if(browserChoice.equalsIgnoreCase("edge")) {
			driver=BrowserConfig.geTBrowser();
		}
		return driver;
	}
	/*****************open website url**************/
	public static void openBrowser(String websiteurl) {
		driver.get(prop.getProperty(websiteurl));
	}
	/*************check if the element is present********/
	public static boolean isElementPresent(By locator,Duration timeout) {
		try {
			new WebDriverWait(driver,timeout)
			.until(ExpectedConditions.presenceOfElementLocated(locator));
			return true;
		}catch(Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	/************** For clicking an element ****************/
	public static void clickOn(WebElement element) {
		try {
			new WebDriverWait(driver,Duration.ofSeconds(15))
			.until(ExpectedConditions.visibilityOf(element));
			element.click();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	 
	    
	    /************** Send text of element ****************/
	    public static void sendtext(WebElement element,String text) {
			try {
				new WebDriverWait(driver,Duration.ofSeconds(15))
				.until(ExpectedConditions.visibilityOf(element));
				element.sendKeys(text);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
	    
	    /*******Retrieving error msg*******/
	    public static String rettext(WebElement element) 
		{
			String text=null;
			try 
			{
				new WebDriverWait(driver,Duration.ofSeconds(15))
				.until(ExpectedConditions.visibilityOf(element));
				text=element.getText();
			}
			catch(Exception e) 
			{
				e.printStackTrace();
			}
			return text;
		}
	    
	    /***********ScrollDown to particular element*********/
	    public static void ScrollDownToElement() {
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0, 400)");
		}
	    
	    /************** For taking screenshot ****************/
	    public static void takeScreenShot(String filePath) {
			try {
				File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(src, new File(filePath));
			}catch(Exception e) {
				e.printStackTrace();
			}
			
		}
	    
	    /*************************Mouse hover***************************/
	    public static void mousehover(WebElement element) {
			 try {
			 new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOf(element));
			 Actions actions = new Actions(driver);
		     actions.moveToElement(element).perform();
			 }catch(Exception e) {
			 e.printStackTrace();
			 }
		}
		
}
