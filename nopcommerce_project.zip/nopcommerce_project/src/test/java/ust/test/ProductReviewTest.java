package ust.test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import ust.base.BaseTest;
import ust.pom.Login;
import ust.utils.ExcelUtility;

@Listeners(ust.utils.SampleListeners.class)
public class ProductReviewTest  extends BaseTest{

	String[][] data;
	@DataProvider(name = "reviewData")
	public Object[][] testdata()
	{
		data=ExcelUtility.testdata2();
		return data;

	}
	
	@Test(priority=0,dataProvider="reviewData")
	public void review(String email,String password) {
		Login pr=new Login(driver);
		pr.login();
		pr.Email(email);
		pr.password(password);
		pr.submit();
	
	}
	

}
