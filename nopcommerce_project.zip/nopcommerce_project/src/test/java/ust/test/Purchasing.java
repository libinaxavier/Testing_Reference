package ust.test;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import ust.base.BaseTest;
import ust.pom.Purchasing1;
import ust.utils.ExcelUtility;

@Listeners(ust.utils.SampleListeners.class)
public class Purchasing extends BaseTest {
	String[][] data;
	public Purchasing(WebDriver driver) {
		// TODO Auto-generated constructor stub
	}

	@DataProvider(name = "purchaseData")
	public Object[][] testdata()
	{
		data=ExcelUtility.testdata1();
		return data;

	}
	
	@Test(priority=0,dataProvider="purchaseData")
	public void Purchasing(String search) {
		Purchasing1 p=new Purchasing1(driver);
		//Verify that two search button is  present
	    SoftAssertions.assertSoftly(softAssertions -> {
	       softAssertions.assertThat(driver.findElement(By.xpath("(//button[text()='Search'])[1]")).isDisplayed());
					
		});
	    
			
		p.Search(search);
		p.SearchBut();
		p.SearchBut1();
		
		// Verify that the cursor is navigating to the correct page
		String a2=p.getURL();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(a2.contains("https://demo.nopcommerce.com/search?q=book&cid=0&mid=0&advs=false&isc=false&sid=false"));
		});
		
		p.Item();
		
		// Verify that the cursor is navigating to the correct page
		String a1=p.getURL();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(a1.contains("https://demo.nopcommerce.com/apple-macbook-pro-13-inch"));
		});
		
		//verify that the Addtocart button present
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.id("add-to-cart-button-4")).isDisplayed());
						
			});
		
		p.AddToCart();
		p.ShoppingCart();
		p.termsAndService();	

          //verify that the checkout button present
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.id("checkout")).isDisplayed());
						
			});
		p.checkOut();
	}
	
	

}
