package ust.test;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import ust.base.BaseTest1;
import ust.base.DriverUtils;
import ust.pom.Registration;
import ust.utils.ExcelUtility;

@Listeners(ust.utils.SampleListeners.class)
public class RegistrationTest extends BaseTest1 {
	
	String[][] data;
	@DataProvider(name = "regData")
	public Object[][] testdata()
	{
		data=ExcelUtility.testdata();
		return data;

	}
	@Test(priority=0,dataProvider="regData")
	public void RegButton(String fname,String lname,String email,String pass,String conpass) {
		try {
		Registration r=new Registration(driver);
		r.RegBut();
		
		// Verify that the cursor is navigating to the registration page
		String a1=r.getURL();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(a1.contains("https://demo.nopcommerce.com/register?returnUrl=%2F"));
		});

		//Verify that firstname field is present
	    SoftAssertions.assertSoftly(softAssertions -> {
	       softAssertions.assertThat(driver.findElement(By.id("FirstName")).isDisplayed());
					
		});
				
		//Verify that lastname field is present
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("LastName")).isDisplayed());
					
		});
				
		//Verify that email field is present
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("Email")).isDisplayed());
					
		});
				
		//Verify that password field is present
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("Password")).isDisplayed());
					
		});
		
		//Verify that Confirm password field is present
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("ConfirmPassword")).isDisplayed());
							
		});
				
		//Verify that Register button is present
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("register-button")).isDisplayed());
					
		});
				
		r.Fname(fname);
		r.Lname(lname);
		r.Email(email);
		r.Pass(pass);
		r.ConPass(conpass);
		r.RegButt();
	String p=r.fnameEmpty();
		String n1=r.LnameEmpty();
		String m1=r.EmailEmpty();
		String m2=r.PassEmpty();
		String m3=r.ConPassEmpty();
		
       if(fname.equals(" ")) {
			//check password error message is displayed when first name field is empty
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(p.equalsIgnoreCase(" First name is required."));
			});
		}
		
		else if(lname.equals("")) {
			
			//check valid error message is displayed when last name field is empty
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(n1.equalsIgnoreCase("Last name is required."));
			});
		}
		else if(email.equals(" ")) {
			
			//check valid error message is displayed when  email field is empty
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(m1.equalsIgnoreCase("Email is required"));
			});
		}
		else if(pass.equals(" ")) {
			
			//check valid error message is displayed when password field is empty
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(m2.equalsIgnoreCase("Password is required"));
			});
		}
		else if(conpass.equals(" ")) {
			
			//check valid error message is displayed when name email field is empty
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(m3.equalsIgnoreCase("Password is required"));
			});
		}
		
	}catch (Exception e) {
        e.printStackTrace();
    }
}
}
	


