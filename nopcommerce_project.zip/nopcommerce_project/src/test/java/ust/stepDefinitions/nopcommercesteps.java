package ust.stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import ust.base.BrowserConfig;
import ust.pom.Login;


public class nopcommercesteps {
	public static String title;
	public WebDriver driver1=BrowserConfig.geTBrowser();
	public Login c1=new Login(driver1);

	@Given("user is on Home page")
	public void user_is_on_home_page() {
	
		driver1.get("https://demo.nopcommerce.com/");
	}

	@When("user gets the title of the page")
	public void user_gets_the_title_of_the_page() {
	    
		title=c1.getTitle();
		System.out.println(title);
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String string) {
		title=c1.getTitle();
		Assert.assertEquals(title,string);
	}

	@When("user enters username {string}")
	public void user_enters_username(String string) {
		Login c1=new Login(driver1);
		c1.login();
		c1.Email(string);

	}

	@When("user enters password {string}")
	public void user_enters_password(String string) {
		Login c1=new Login(driver1);
		c1.password(string);
	}

	@When("user clicks on Login button")
	public void user_clicks_on_login_button() {
	
		Login c1=new Login(driver1);
		   c1.submit();
	}
}
