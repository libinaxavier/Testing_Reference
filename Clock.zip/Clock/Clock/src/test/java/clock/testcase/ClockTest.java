package clock.testcase;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import clock.base.BaseTest;
import clock.page.ClockPage;

@Listeners(utilities.SampleListener.class)
public class ClockTest extends BaseTest{
	
	@DataProvider(name="cityData")
	public Object[][] getData() throws IOException
	{
		List<HashMap<String, String>>	data =getJsonData(System.getProperty("user.dir")+"\\TestData\\clock.json");
		Object[][] testData = new Object[data.size()][1];

	    for (int i = 0; i < data.size(); i++) {
	        HashMap<String, String> row = data.get(i);
	        testData[i][0] = row.get("city");
	    }

	    return testData;
	}
	@Test(priority=1,dataProvider="cityData")
	public void alarmTest(String city) throws InterruptedException {
		ClockPage c1=new ClockPage(driver);
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.id("com.google.android.deskclock:id/toolbar")).isDisplayed());
						
			});
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.id("com.google.android.deskclock:id/digital_clock")).isDisplayed());
						
			});
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.id("com.google.android.deskclock:id/date")).isDisplayed());
						
			});
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.id("com.google.android.deskclock:id/fab")).isDisplayed());
						
			});
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.xpath("//android.widget.FrameLayout[@content-desc=\"Alarm\"]")).isDisplayed());
						
			});
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.xpath("//android.widget.FrameLayout[@content-desc=\"Clock\"]")).isDisplayed());
						
			});
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.xpath("//android.widget.FrameLayout[@content-desc=\"Timer\"]")).isDisplayed());
						
			});

		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.xpath("//android.widget.FrameLayout[@content-desc=\"Bedtime\"]")).isDisplayed());
						
			});
		
		c1.alarmClick();
		c1.addAlarm();
		c1.addHr();
		c1.addMin();
		c1.addAm();
		c1.okClick();
		c1.monClick();
		c1.collpaseClick();
		c1.clockClick();
		c1.cityClick();
		c1.citySearch(city);
		driver.findElement(By.id("com.google.android.deskclock:id/city_name")).click();
		
//		SoftAssertions.assertSoftly(softAssertions -> {
//		       softAssertions.assertThat(driver.findElement(By.id("com.google.android.deskclock:id/action_bar_title")).isDisplayed());
//						
//			});
//		Thread.sleep(2000);
//	
//		SoftAssertions.assertSoftly(softAssertions -> {
//		       softAssertions.assertThat(driver.findElement(By.id("com.google.android.deskclock:id/stopwatch_time_text")).isDisplayed());
//						
//			});
//		
//		SoftAssertions.assertSoftly(softAssertions -> {
//		       softAssertions.assertThat(driver.findElement(By.id("com.google.android.deskclock:id/stopwatch_hundredths_text")).isDisplayed());
//						
//			});
		
		
		c1.stopwatchClick();
		c1.play();
		Thread.sleep(2000);
		c1.pause();
	}

}