package test;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Base.BaseTest1;
import page.LoginReview_page;
import utils.ExcelUtility2;
import utils.ExcelUtility3;
import utils.Excelutility1;

public class LoginReview_test extends BaseTest1 {
	WebDriver driver;
	WebElement element;
	LoginReview_page logrev;
    String[][] data;
	
    @DataProvider(name = "testData")
	public Object[][] testdata(){
		data= Excelutility1.testdata();
		return data;
	}
    @DataProvider(name = "testData1")
   	public Object[][] testdata1(){
   		data= ExcelUtility2.testdata();
   		return data;
   	}
    @DataProvider(name = "testData2")
   	public Object[][] testdata2(){
   		data= ExcelUtility3.testdata();
   		return data;
   	}
    
    @Test(priority=0)
	public void Login() {
		
		LoginReview_page l=new LoginReview_page(driver);
		l.Loginclick1();
		String a=BaseTest1.getUrl();
	    
		 SoftAssertions.assertSoftly(softAssertions -> {
		 softAssertions.assertThat(a.contains("https://www.biotique.com/account"));
		 });
	}
	@Test(priority=1,dataProvider = "testData")
	public void signin(String email1,String password1) {
		LoginReview_page l1=new LoginReview_page(driver);
		l1.Email(email1);
		l1.Password(password1);
		l1.signinclick();
		l1.Home();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//span[normalize-space()='Support']")).isDisplayed());});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//button[text()='Search']")).isDisplayed());});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//span[text()='Cart']")).isDisplayed());});
		
	}
	@Test(priority=2,dataProvider = "testData1")
	public void Searchtext(String search1) {
		LoginReview_page l2=new LoginReview_page(driver);
		l2.Search1(search1);
		l2.Search2();
		l2.Image();
		String a=BaseTest1.getUrl();
		SoftAssertions.assertSoftly(softAssertions -> {
			 softAssertions.assertThat(a.contains("https://www.biotique.com/products/honey-gel-soothe-nourish-foaming-face-wash?_pos=1&_sid=e65f5198d&_ss=r"));
			 });
		SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(driver.findElement(By.xpath("//button[@class='btn-add-alireview alireview-btn--1']")).isDisplayed());});
	}
	@Test(priority=3,dataProvider="testData2")
	public void Review(String feedback1, String yourname1,String youremail1) {
		LoginReview_page l3=new LoginReview_page(driver);
	    l3.Review();
	    SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("content")).isDisplayed());});
	    SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("your_name")).isDisplayed());});
	    SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("your_email")).isDisplayed());});
	    SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("btn-add-review")).isDisplayed());});
	    l3.Feedback(feedback1);
	    l3.YourName(yourname1);
	    l3.YourEmail(youremail1);
	    l3.SubmitReview();
	}

}
