package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.DriverUtils;

public class LoginReview_page extends DriverUtils {

	private WebDriver driver;
	public LoginReview_page(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
		}
	
	@FindBy(xpath="//span[@class=\"name-list-h\"][text()='Login']")
	private WebElement login1;
	
	@FindBy(id="CustomerEmail")
	private WebElement email;
	
	@FindBy(id="CustomerPassword")
	private WebElement password;
	
	@FindBy(className="signin-form-validation")
	private WebElement signin;
	
	@FindBy(xpath="//a[@class='breadcrumbs__link']") 
	private WebElement home;
	
	@FindBy(id="Search")
	private WebElement search;
	
	@FindBy(className="btn-searchbar")
	private WebElement searchs;
	
	@FindBy(className="prd-h-img")
	private WebElement img;
	
	@FindBy(xpath="//button[@class='btn-add-alireview alireview-btn--1']")
	private WebElement review;
	
	@FindBy(id="content")
	private WebElement feedback;
	
	@FindBy(id="your_name")
	private WebElement yourname;
	
	@FindBy(id="your_email")
	private WebElement youremail;
	
	@FindBy(id="btn-add-review")
	private WebElement  submitreview;
	
	public void Loginclick1() {
		clickOn(login1);
		}
     public void Email(String email1) {
    	 sendtext(email,email1);	 
     }
     public void Password(String password1) {
    	 sendtext(password,password1);	 
     }
     public void signinclick() {
 		clickOn(signin);
 		}
     public void Home() {
 		clickOn(home);
 	}
     public void Search1(String search1) {
    	 sendtext(search, search1);	 
     }
     public void Search2() {
  		clickOn(searchs);
  	}
     public void Image() {
   		clickOn(img);
   	}
// public void Scroll() {
//	 scrollDownToElement(review);
// }
 public void Review() {
	 ScrollDown();
	 clickOn(review);
	 
 }
 public void Feedback(String feedback1) {
	 sendtext(feedback, feedback1);	 
 }
 public void YourName(String yourname1) {
	 sendtext(yourname, yourname1);	 
 }
 public void YourEmail(String youremail1) {
	 sendtext(youremail, youremail1);	 
 }
 public void SubmitReview() {
	 clickOn(submitreview);
 }
}
