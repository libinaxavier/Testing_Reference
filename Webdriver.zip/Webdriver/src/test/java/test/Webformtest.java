package test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseTest;
import pom.Webform;

public class Webformtest extends BaseTest {
	
	@DataProvider(name = "logData1")
	public Object[][] getData() throws IOException
	{
	List<HashMap<String, String>>	data =getJsonData(System.getProperty("user.dir")+"\\src\\TestData\\signup.json");
	Object[][] testData = new Object[data.size()][3];
	for (int i = 0; i < data.size(); i++) {
	HashMap<String, String> row = data.get(i);
	testData[i][0] = row.get("email");
	testData[i][1] = row.get("pssword");
	testData[i][2] = row.get("conpass");
	}
	return testData;
	}

	@Test(priority=0)
	public void  test() {
		Webform wf=new Webform(driver);
		wf.webclick();
	}

	@Test(priority=1,dataProvider="logData1")
	public void test3(String email,String password,String conpass) {
		Webform wf=new Webform(driver);
		wf.loginclick();
		wf.signupclick();
		wf.emailtxt(email);
		wf.passtxt(password);
		wf.conpasstxt(conpass);
		wf.submitclick();
	}

}
