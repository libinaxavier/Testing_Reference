package pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import base.AndroidActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class Webform  extends AndroidActions{

	public Webform(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver),this);
		
	}
	
	@AndroidFindBy(xpath="//android.widget.Button[@content-desc=\"Webview\"]/android.widget.TextView[2]")
	WebElement web;
	
	@AndroidFindBy(xpath="//android.widget.Button[@content-desc=\"Login\"]/android.widget.TextView[2]")
	WebElement login;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"button-sign-up-container\"]/android.view.ViewGroup/android.widget.TextView")
	WebElement signup;
	
	@AndroidFindBy(xpath="//android.widget.EditText[@content-desc=\"input-email")
	WebElement email;
	
	@AndroidFindBy(xpath="//android.widget.EditText[@content-desc=\"input-password\"]")
	WebElement pass;
	
	@AndroidFindBy(xpath="//android.widget.EditText[@content-desc=\"input-repeat-password\"]")
	WebElement conpass;
	
	@AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"button-SIGN UP\"]/android.view.ViewGroup")
	WebElement submit;
	
	
	public void webclick() {
		web.click();
	}
	
	public void loginclick() {
		login.click();
	}
	
	public void signupclick() {
		signup.click();
	}
	
	public void emailtxt(String email1) {
		email.sendKeys(email1);
	}
	
	public void passtxt(String pass1) {
		pass.sendKeys(pass1);
	}
	
	public void conpasstxt(String conpass1) {
		conpass.sendKeys(conpass1);
	}
	public void submitclick() {
		submit.click();
	}
	

}
