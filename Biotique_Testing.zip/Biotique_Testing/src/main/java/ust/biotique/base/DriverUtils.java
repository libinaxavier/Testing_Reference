package ust.biotique.base;

import java.io.File;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import ust.biotique.utils.FileIo;

public class DriverUtils {

	public static  WebDriver driver;
	public static Properties prop;
	public static String browserChoice;
	public DriverUtils() {
		prop=FileIo.initProperties();
	}
	
	/*****************Invoke browser**************************/
	public static WebDriver invokeBrowser() {
		browserChoice = prop.getProperty("browserName");
		if (browserChoice.equalsIgnoreCase("chrome")) {
			driver = BrowserConfig.getBrowser();
		}
		return driver;
	}
	
	/*******************Open website url*********************/
	public static void openBrowser(String websiteurl) {
		driver.get(prop.getProperty(websiteurl));
		}
	
	/******************Check if element is present**************/
	public static boolean isElementPresent(By locator,Duration timeout) {
		try {
		new WebDriverWait(driver,timeout)
		.until(ExpectedConditions.presenceOfElementLocated(locator));
		return true;
		}catch(Exception e) {
		e.printStackTrace();
		return false;
		}
		}
	
	/**********************Get text of element*********************/
		    public static String getText(WebElement element) {
		String text = null;
		        try {
		            new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOf(element));
		            text = element.getText();
		} catch (Exception e) {
		            e.printStackTrace();
		}
		        return text;
		}
		    
     /*************************Send text of element******************/
		    public static void sendtext(WebElement element,String text) {
		try {
		new WebDriverWait(driver,Duration.ofSeconds(15))
		.until(ExpectedConditions.visibilityOf(element));
		element.sendKeys(text);
		}catch(Exception e) {
		e.printStackTrace();
		}
		}
		    
    /************************For clicking an element*********************/
		    public static void clickOn(WebElement element) {
		try {
		new WebDriverWait(driver,Duration.ofSeconds(15))
		.until(ExpectedConditions.visibilityOf(element));
		element.click();
		}catch(Exception e) {
		e.printStackTrace();
		}
		}
		    
	/***********************For taking screenshot************************/
		    public static void takeScreenShot(String filePath) {
		try {
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File(filePath));
		}catch(Exception e) {
		e.printStackTrace();
		}
		}
		    
    /*************************Switch to alert and accept******************/
		public void switchtoAlert() {
		try {
		new WebDriverWait(driver,Duration.ofSeconds(15))
		.until(ExpectedConditions.alertIsPresent());
		driver.switchTo().alert().accept();
		}catch(Exception e) {
		e.printStackTrace();
		}
		}
		
	/*********************Switch to alert and extract text***************/
		public String getTextfromAlertandAccept() {
		String text=null;
		try {
		new WebDriverWait(driver,Duration.ofSeconds(15))
		.until(ExpectedConditions.alertIsPresent());
		Alert alert =driver.switchTo().alert();
		text=alert.getText();
		alert.accept();
		}catch(Exception e) {
		e.printStackTrace();
		}
		return text;
		}
		
	/****************Retrieving error message**********************/	
		public static String rettext(WebElement element)
		{
		String text=null;
		try
		{
		new WebDriverWait(driver,Duration.ofSeconds(15))
		.until(ExpectedConditions.visibilityOf(element));
		text=element.getText();
		}
		catch(Exception e)
		{
		e.printStackTrace();
		}
		return text;
		}
		
	/***********************For dropdownList***********************/
		public static String getSelectedOptionFromDropdown(WebElement element) {
		String text = null;
		try {
		new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOf(element));
		Select s = new Select(element);
		} catch (Exception e) {
		e.printStackTrace();
		}
		return text;
		}
		
   /****************************Mouse hover****************************/
//		public static void mouseOver(WebElement element) {
//			try {
//				new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOf(element));
//				WebElement target=driver.findElement(element);
//		        Actions actions = new Actions(driver);
//		        actions.moveToElement(target).perform();
//			}catch(Exception e) {
//				e.printStackTrace();
//			}
//}
		
	/***************************Wait for  Text****************************/
		public static void waitForText(WebDriver driver, String text, By by, String timeoutMsg) throws Exception {
	        try {
	new WebDriverWait(driver,Duration.ofSeconds(10)).until(ExpectedConditions.textToBePresentInElementLocated(by, text));
	} catch (Exception e) {
	            e.printStackTrace();
	}
	}
		public static void ScrollDown() {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			try {
			js.executeScript("window.scrollBy(0, 500)"); // Scroll down by 500 pixels vertically
			} catch (Exception e) {
			e.printStackTrace();
			// Handle the exception appropriately
			}
			}
		

}
