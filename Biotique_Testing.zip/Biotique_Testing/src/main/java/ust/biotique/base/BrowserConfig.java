package ust.biotique.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;

public class BrowserConfig {
//	static WebDriver driver;
//	public static WebDriver getBrowser() {
//	ChromeOptions option=new ChromeOptions();
//	option.addArguments("--disable-notifications");
//	option.addArguments("--remote-allow-origins=*");
//	driver=new ChromeDriver(option);
//	driver.manage().window().maximize();
//	return driver;
//
//	}
	static WebDriver driver;
	public static WebDriver getBrowser() {
	driver=new EdgeDriver(); //Configuring edge driver
	driver.get("https://casekaro.com/");   //Application url
	driver.manage().window().maximize(); //Maximize the window
	return driver;
}
}
