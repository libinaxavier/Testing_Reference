package ust.biotique.test;

import org.testng.annotations.Test;

import ust.biotique.base.BaseTest;
import ust.biotique.page.Hotelandspa_page;

public class Hotelandspa_Tests extends BaseTest {

	@Test(priority=1)
	public void hotelField() {
		Hotelandspa_page h1=new Hotelandspa_page();
		h1.Hotellogin();
		}
	@Test(priority=2)
	public void hotelDetails() {
	Hotelandspa_page h1=new Hotelandspa_page();
	h1.hotelName("Hila");
	h1.ContactPersonName("Rajeev");
	h1.hotelNums("1");
	h1.Designation("Manager");
	}
}
