package endpoints;

public class Route_commerce {

	public static String baseuri="http://localhost:8080"; //BASE URL
	public static String post_basePath="/products";
	public static String get_basePath="/products/{id}";
	public static String delete_basePath="/products/{id}";
	public static String update_basePath="/products/{id}";
}
