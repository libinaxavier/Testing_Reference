package com.example.endpoints;

public class Routes {

	public static String baseuri="https://jsonplaceholder.typicode.com";
	public static String post_basePath="/comments";
	public static String get_basePath="/comments/{id}";
	public static String delete_basePath="/comments/{id}";
	public static String update_basePath="/comments/{id}";
	
}