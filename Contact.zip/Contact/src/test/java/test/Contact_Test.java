package test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.BaseTest_contact;
import io.appium.java_client.AppiumBy;
import pageFactory.ContactForm;

@Listeners(utilities.SampleListener.class)
public class Contact_Test  extends BaseTest_contact{
	@DataProvider(name = "logData1")
	public Object[][] getData() throws IOException
	{
	List<HashMap<String, String>>	data =getJsonData(System.getProperty("user.dir")+"\\src\\TestData\\contact.json");
	Object[][] testData = new Object[data.size()][3];
	for (int i = 0; i < data.size(); i++) {
	HashMap<String, String> row = data.get(i);
	testData[i][0] = row.get("firstname");
	testData[i][1] = row.get("lastname");
	testData[i][2] = row.get("Phone");
	}
	return testData;
	}

	
	@Test(priority=1,dataProvider="logData1")
	public void conttest(String firstname,String lastname,String Phone) {
		ContactForm cf= new ContactForm(driver);
		SoftAssert softassert=new SoftAssert();
		String msg="Contacts";
		softassert.assertEquals(driver.findElement(AppiumBy.id("com.google.android.contacts:id/product_name")).getText()
		.equalsIgnoreCase(msg), true);
		
		String msg2="Skip";
		softassert.assertEquals(driver.findElement(AppiumBy.id("android:id/button2")).getText()
		.equalsIgnoreCase(msg2), true);
		
		cf.skipclick();
		
		String allowmsg="Allow";
		softassert.assertEquals(driver.findElement(AppiumBy.id("com.android.permissioncontroller:id/permission_allow_button")).getText()
		.equalsIgnoreCase(allowmsg), true);
		
		String disallowmsg="Allow";
		softassert.assertEquals(driver.findElement(AppiumBy.id("com.android.permissioncontroller:id/permission_deny_button")).getText()
		.equalsIgnoreCase(disallowmsg), true);
		
		String contactpresent="Allow";
		softassert.assertEquals(driver.findElement(AppiumBy.id("com.android.permissioncontroller:id/permission_deny_button")).getText()
		.equalsIgnoreCase(disallowmsg), true);
		
		cf.allowclick();
		cf.addcontactclick();
		cf.firstname(firstname);
		cf.lasttname(lastname);
		cf.phone(Phone);
		cf.saveclick();
		cf.msgclick();
		cf.msgboxclick();
		cf.msgtext();
		cf.clickon();
		cf.bckclick();
		
	}
	
	

}
