package pageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import base.AndroidActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class ContactForm extends AndroidActions {

	AndroidDriver driver;

	public ContactForm(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver),this);
	}
	
	@AndroidFindBy(id="android:id/button2")
	WebElement skip;
	
	@AndroidFindBy(id="com.android.permissioncontroller:id/permission_allow_button")
	WebElement allow;
	
	@AndroidFindBy(xpath="//android.widget.ImageButton[@content-desc=\"Create contact\"]")
	WebElement addcontact;
	
	@AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/android.widget.LinearLayout/android.view.ViewGroup/android.widget.LinearLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout[1]/android.widget.FrameLayout/android.widget.EditText")
	WebElement firstname;
	
	@AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/android.widget.LinearLayout/android.view.ViewGroup/android.widget.LinearLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.EditText")
	WebElement lastname;
	
	@AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/android.widget.LinearLayout/android.view.ViewGroup/android.widget.LinearLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout[3]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.EditText")
	WebElement phn;
	
	@AndroidFindBy(id="com.google.android.contacts:id/toolbar_button")
	WebElement save;
	
	@AndroidFindBy(id="com.google.android.contacts:id/verb_text")
	WebElement mesg;
	
	@AndroidFindBy(id="com.google.android.apps.messaging:id/compose_message_text")
	WebElement msgbox;

	@AndroidFindBy(xpath="//android.widget.ImageView[@content-desc=\"Send SMS\"]")
	WebElement msgsent;
	
	@AndroidFindBy(xpath="//android.widget.ImageButton[@content-desc=\"Navigate up\"]")
	WebElement back;
	
	public void skipclick() {
		skip.click();
	}
	
	public void allowclick() {
		allow.click();
	}
	
	public void addcontactclick() {
		addcontact.click();
	}
	
	public void firstname(String fname) {
		firstname.sendKeys(fname);
	}
	
	public void lasttname(String lname) {
		lastname.sendKeys(lname);
	}
	
	public void phone(String phn1) {
		phn.sendKeys(phn1);
	}
	
	public void saveclick() {
		save.click();
	}
	
	public void msgclick() {
		mesg.click();
	}
	
	public void msgboxclick() {
		msgbox.click();
	}
	
	public void msgtext() {
		msgbox.sendKeys("hai");
	}
	public void clickon() {
		msgsent.click();
	}
	
	public void bckclick() {
		back.click();
	}
	

}
